# views.py
from django.shortcuts import render, redirect
from django.forms import formset_factory
from .forms import OrderForm, OrderItemForm
from .models import Order, OrderItem

def pos_screen(request):
    OrderItemFormSet = formset_factory(OrderItemForm, extra=1)  # Allow multiple products in one order

    if request.method == 'POST':
        order_form = OrderForm(request.POST)
        order_item_formset = OrderItemFormSet(request.POST)

        if order_form.is_valid() and order_item_formset.is_valid():
            # Save the order
            order = order_form.save(commit=False)
            order.business = request.user.business  # Assuming the user is associated with a business
            order.save()

            # Save order items
            for form in order_item_formset:
                if form.cleaned_data.get('product'):
                    order_item = form.save(commit=False)
                    order_item.order = order
                    order_item.unit_price = order_item.product.price  # Set unit price from product
                    order_item.save()

            return redirect('order_detail', order_id=order.id)  # Redirect to order detail page

    else:
        order_form = OrderForm()
        order_item_formset = OrderItemFormSet()

    context = {
        'order_form': order_form,
        'order_item_formset': order_item_formset,
    }
    return render(request, 'sales/pos_screen.html', context)