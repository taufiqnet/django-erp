from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Business, Contact, Product, Order, OrderItem
import json
from decimal import Decimal
import logging

logger = logging.getLogger(__name__)

def dashboard(request):
    return render(request, 'sales/dashboard_sales.html')

def sales_view(request):
    """Render the sales page with customers and products."""
    businesses = Business.objects.all()
    customers = Contact.objects.filter(type='customer')  # Filter only customers
    products = Product.objects.all()
    return render(request, "sales/sales.html", {"businesses": businesses, "customers": customers, "products": products})

def customer_search(request):
    """AJAX endpoint to search customers dynamically."""
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        q = request.GET.get('q', '').strip()
        customers = Contact.objects.filter(type='customer', first_name__icontains=q)[:10]  # Limit results to 10
        results = [{"id": customer.id, "text": customer.first_name} for customer in customers]
        return JsonResponse({"results": results})
    return JsonResponse({"error": "Invalid request"}, status=400)

@csrf_exempt
def get_product_details(request):
    """AJAX endpoint to fetch product details (price) when selected."""
    if request.method == "POST":
        data = json.loads(request.body)
        product_id = data.get("product_id")

        product = get_object_or_404(Product, id=product_id)
        return JsonResponse({"unit_price": str(product.price)})

    return JsonResponse({"error": "Invalid request"}, status=400)

@csrf_exempt
def create_order(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            business_id = data.get('business_id')
            customer_id = data.get('customer_id')
            shipping_cost = Decimal(data.get('shipping_cost', 0))
            order_discount = Decimal(data.get('order_discount', 0))
            total_amount = Decimal(data.get('total_amount', 0))
            products = data.get('products', [])

            # Create and save the Order instance first
            order = Order(
                business_id=business_id,
                customer_id=customer_id,
                shipping_cost=shipping_cost,
                discount=order_discount,
                total_amount=total_amount,
            )
            order.save()  # Save the order to generate a primary key

            # Add order items after the order has been saved
            for product in products:
                OrderItem.objects.create(
                    order=order,  # Now the order has a primary key
                    product_id=product['product_id'],
                    quantity=product['quantity'],
                    item_discount=Decimal(product['item_discount']),
                    total_price=Decimal(product['total_price']),
                )

            return JsonResponse({'order_id': order.id, 'message': 'Order created successfully'}, status=201)

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)

    return JsonResponse({'error': 'Invalid request method'}, status=405)

def sales_list(request):
    """Display the list of sales transactions."""
    orders = Order.objects.all().order_by("-id")
    return render(request, "sales/sales_list.html", {"orders": orders})