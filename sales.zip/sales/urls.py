from django.urls import path
from sales import views

app_name = "sales" 

urlpatterns = [
    path("", views.dashboard, name="dashboard-hrm"),
    path("sales/", views.sales_view, name="sales"),

    # Searching customer in sales.html
    path("customer-search/", views.customer_search, name="customer_search"),
    
    path("create_order/", views.create_order, name="create_order"),
    path("sales_list/", views.sales_list, name="sales_list"),
]

